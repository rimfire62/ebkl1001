#include <gtk/gtk.h>

/* Callback: wird aufgerufen, wenn der Button geklickt wird */
static void on_button_clicked(GtkButton *button, gpointer user_data)
{
    GtkLabel *label = GTK_LABEL(user_data);
    gtk_label_set_text(label, "Button wurde geklickt!");
}

static void activate(GtkApplication *app, gpointer user_data)
{
    /* Fenster erstellen */
    GtkWidget *window = gtk_application_window_new(app);
    gtk_window_set_title(GTK_WINDOW(window), "GTK4 Beispiel");
    gtk_window_set_default_size(GTK_WINDOW(window), 420, 200);

    /* Layout-Container */
    GtkWidget *box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 12);
    gtk_widget_set_margin_top(box, 16);
    gtk_widget_set_margin_bottom(box, 16);
    gtk_widget_set_margin_start(box, 16);
    gtk_widget_set_margin_end(box, 16);

    /* Widgets */
    GtkWidget *label = gtk_label_new("Hallo GTK4 in C!");
    GtkWidget *button = gtk_button_new_with_label("Klick mich");

    /* Signal verbinden: button "clicked" -> on_button_clicked(label) */
    g_signal_connect(button, "clicked", G_CALLBACK(on_button_clicked), label);

    /* In Box packen */
    gtk_box_append(GTK_BOX(box), label);
    gtk_box_append(GTK_BOX(box), button);

    /* Box ins Fenster setzen und anzeigen */
    gtk_window_set_child(GTK_WINDOW(window), box);
    gtk_window_present(GTK_WINDOW(window));
}

int main(int argc, char **argv)
{
    GtkApplication *app = gtk_application_new("com.example.gtk4demo", G_APPLICATION_DEFAULT_FLAGS);
    g_signal_connect(app, "activate", G_CALLBACK(activate), NULL);

    int status = g_application_run(G_APPLICATION(app), argc, argv);
    g_object_unref(app);
    return status;
}

