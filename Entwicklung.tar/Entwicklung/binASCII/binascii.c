#include "binascii.h"
#include <ctype.h>
#include <limits.h>

static int write_fixed_u32(uint32_t u, char *out, size_t out_sz) {
    if (!out || out_sz < 33) return BINASCII_ENOBUF;

    for (int i = 31; i >= 0; --i) {
        out[31 - i] = (char)('0' + ((u >> i) & 1u));
    }
    out[32] = '\0';
    return BINASCII_OK;
}

int int32_to_bin_ascii_fixed(int32_t value, char *out, size_t out_sz) {
    uint32_t u = (uint32_t)value; /* bitweise Darstellung in Zweierkomplement */
    return write_fixed_u32(u, out, out_sz);
}

int int32_to_bin_ascii_min(int32_t value, char *out, size_t out_sz) {
    if (!out) return BINASCII_EINVAL;

    uint32_t u = (uint32_t)value;

    /* Sonderfall: 0 */
    if (u == 0u) {
        if (out_sz < 2) return BINASCII_ENOBUF;
        out[0] = '0';
        out[1] = '\0';
        return BINASCII_OK;
    }

    /* Finde höchstgesetztes Bit */
    int msb = 31;
    while (msb > 0 && ((u >> msb) & 1u) == 0u) {
        --msb;
    }

    size_t needed = (size_t)msb + 2; /* Bits + '\0' */
    if (out_sz < needed) return BINASCII_ENOBUF;

    size_t pos = 0;
    for (int i = msb; i >= 0; --i) {
        out[pos++] = (char)('0' + ((u >> i) & 1u));
    }
    out[pos] = '\0';
    return BINASCII_OK;
}

static const char* skip_ws(const char *p) {
    while (p && *p && isspace((unsigned char)*p)) ++p;
    return p;
}

int bin_ascii_to_int32(const char *str, int32_t *out) {
    if (!str || !out) return BINASCII_EINVAL;

    const char *p = skip_ws(str);

    /* optional 0b / 0B */
    if (p[0] == '0' && (p[1] == 'b' || p[1] == 'B')) {
        p += 2;
    }

    uint32_t acc = 0u;
    int bits = 0;
    int saw_bit = 0;

    for (; *p; ++p) {
        unsigned char c = (unsigned char)*p;

        if (c == '_') {
            continue; /* Trenner */
        }
        if (c == '0' || c == '1') {
            saw_bit = 1;

            if (bits >= 32) {
                return BINASCII_ERANGE; /* zu viele Bits */
            }

            acc = (acc << 1) | (uint32_t)(c - '0');
            bits++;
            continue;
        }

        if (isspace(c)) {
            /* erlauben: trailing spaces, aber danach darf nix mehr kommen */
            p = skip_ws(p);
            if (*p != '\0') return BINASCII_EINVAL;
            break;
        }

        return BINASCII_EINVAL; /* ungültiges Zeichen */
    }

    if (!saw_bit) return BINASCII_EINVAL;

    /* acc ist 32-bit Muster. Umwandlung zu int32_t in Zweierkomplement:
       Das Casting von uint32_t nach int32_t ist in C implementierungsdefiniert,
       aber auf praktisch allen modernen Systemen Zweierkomplement.
       Um es streng portabel zu machen, bilden wir manuell:
    */
    if (acc <= (uint32_t)INT32_MAX) {
        *out = (int32_t)acc;
    } else {
        /* negatives Ergebnis: -(~acc + 1) */
        uint32_t magnitude = (~acc) + 1u;
        if (magnitude > (uint32_t)INT32_MAX + 1u) return BINASCII_ERANGE;
        *out = -(int32_t)magnitude;
    }

    return BINASCII_OK;
}