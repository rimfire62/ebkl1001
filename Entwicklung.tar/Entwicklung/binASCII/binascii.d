binascii.o: binascii.c binascii.h
binascii.h:
