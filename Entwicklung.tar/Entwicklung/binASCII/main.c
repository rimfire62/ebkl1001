#include <stdio.h>
#include "binascii.h"

int main(void) {
    char buf[64];

    int32_t v = 10;
    int32_to_bin_ascii_fixed(v, buf, sizeof buf);
    printf("fixed: %d -> %s\n", v, buf);

    int32_to_bin_ascii_min(v, buf, sizeof buf);
    printf("min  : %d -> %s\n", v, buf);

    const char *s = "0b1111_0000";
    int32_t parsed = 0;
    int rc = bin_ascii_to_int32(s, &parsed);
    if (rc == 0) {
        printf("parse: %s -> %d\n", s, parsed);
    } else {
        printf("parse error rc=%d\n", rc);
    }

    /* negatives Beispiel: -1 als 32-bit */
    int32_to_bin_ascii_fixed(-1, buf, sizeof buf);
    printf("fixed: -1 -> %s\n", buf);

    rc = bin_ascii_to_int32(buf, &parsed);
    printf("roundtrip: %s -> %d (rc=%d)\n", buf, parsed, rc);
    printf("fertig.");
    return 0;
}