#ifndef BINASCII_H
#define BINASCII_H

#include <stddef.h>
#include <stdint.h>



/**
 * Konvertiert einen int32_t in eine 32-bit binäre ASCII-Zeichenkette.
 *
 * Ausgabeformat: genau 32 Zeichen ('0'/'1') + '\0' Terminator.
 *
 * @param value   Eingabewert (int32_t)
 * @param out     Zielpuffer
 * @param out_sz  Größe des Zielpuffers in Bytes (mind. 33)
 * @return 0 bei Erfolg, sonst Fehlercode.
 */
int int32_to_bin_ascii_fixed(int32_t value, char *out, size_t out_sz);

/**
 * Konvertiert einen int32_t in eine binäre ASCII-Zeichenkette ohne führende Nullen.
 *
 * Beispiel: 10 -> "1010", 0 -> "0"
 *
 * @param value   Eingabewert
 * @param out     Zielpuffer
 * @param out_sz  Größe des Zielpuffers (mind. 2; worst-case 33)
 * @return 0 bei Erfolg, sonst Fehlercode.
 */
int int32_to_bin_ascii_min(int32_t value, char *out, size_t out_sz);

/**
 * Parst eine binäre ASCII-Zeichenkette in einen int32_t.
 *
 * Akzeptiert:
 *  - führende Whitespaces
 *  - optionales Präfix 0b/0B
 *  - optionale Trenner '_' zwischen Bits
 *  - danach optional Whitespaces bis Stringende
 *
 * Beispiele:
 *  "1010" -> 10
 *  "0b1111_0000" -> 240
 *
 * Hinweis:
 *  - max. 32 Bits (ohne '_' und Präfix) erlaubt.
 *  - Überlauf wird erkannt.
 *
 * @param str   Eingabe-String
 * @param out   Ausgabe-Zeiger auf int32_t
 * @return 0 bei Erfolg, sonst Fehlercode.
 */
int bin_ascii_to_int32(const char *str, int32_t *out);

/** Fehlercodes */
enum {
    BINASCII_OK = 0,
    BINASCII_EINVAL = 1,   /**< ungültige Parameter oder ungültige Zeichen */
    BINASCII_ERANGE = 2,   /**< Überlauf / zu viele Bits */
    BINASCII_ENOBUF = 3    /**< Zielpuffer zu klein */
};



#endif /* BINASCII_H */